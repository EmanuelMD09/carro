function carro(){
    const modelo = document.getElementById("modelo")
    const marca = document.getElementById("marca")
    
    const carro = {
        marca : marca.value,
        modelo : modelo.value
    }
    localStorage.setItem("carro", JSON.stringify(carro))
}